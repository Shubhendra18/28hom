﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using MandiParishadWebApi.Models;

namespace MandiParishadWebApi.Models
{
    public class UserContext : DbContext
    {
        public UserContext() : base("MandiContext")
        {

        }
        public List<UserInbox> GetUsermail(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@Rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewInboxMail @Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public UserInbox GetUsermailDetails(MailDes mailDes)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailId",Value=mailDes.MailId},
                new SqlParameter {ParameterName="@Rid",Value=mailDes.Rid }

                 };
            var sqlQuery = @"Sp_NewMailDes @mailId,@Rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        public string DeleteFromTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewDeleteFromTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        //**********************Has to be update later
        #region tobeupdate
        public string MoveToTrash(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoTrash @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToTrash(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewAllMailToTrash @rid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromTrash(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewMailStoredInTrash @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string MoveToArchive(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewMovetoArchive @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public string AllMailMoveToArchive(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewSendAllMailToArchive @rid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromArchive(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetMailStoredInArchive @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public string MovebackToInbox(MoveToInbox moveTo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=moveTo.mailId},
                new SqlParameter {ParameterName="@flag",Value=moveTo.flag}
                 };
            var sqlQuery = @"Sp_NewSendBackToInbox @mailid,@flag";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        public string MoveToImportant(Int64 MailId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@mailid",Value=MailId}
                 };
            var sqlQuery = @"Sp_NewAddToImportant @mailid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserInbox> GetFromImportant(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewGetAllFromImportant @rid";
            var res = this.Database.SqlQuery<UserInbox>(sqlQuery, sqlParam).ToList();
            return res;
        }

        #endregion

    }
}