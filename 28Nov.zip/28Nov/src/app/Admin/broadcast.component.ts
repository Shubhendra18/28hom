import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-broadcast',
  templateUrl: './broadcast.component.html',
  styles: []
})
export class BroadcastComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
