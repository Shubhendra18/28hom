import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-lastloginreport',
  templateUrl: './lastloginreport.component.html',
  styles: []
})
export class LastloginreportComponent implements OnInit {
  loginrptData: any = [];
  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.GetLastLogin().subscribe(k => {
      this.loginrptData = k;
    });
  }

}
