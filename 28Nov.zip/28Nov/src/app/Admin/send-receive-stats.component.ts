import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-receive-stats',
  templateUrl: './send-receive-stats.component.html',
  styles: []
})
export class SendReceiveStatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
