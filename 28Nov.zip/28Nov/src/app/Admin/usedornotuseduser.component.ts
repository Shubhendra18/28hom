import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usedornotuseduser',
  templateUrl: './usedornotuseduser.component.html',
  styles: []
})
export class UsedornotuseduserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
