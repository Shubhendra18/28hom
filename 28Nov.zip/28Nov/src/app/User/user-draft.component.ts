import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-draft',
  templateUrl: './user-draft.component.html',
  styles: []
})
export class UserDraftComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService, private toastr: ToastrService) { }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  ngOnInit() {
    this.service.allMailFromArchive(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  BackToInbox(mailId) {
    this.service.backToInbox(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('moved To Inbox!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }
}
